function mostrar(params) {
    document.getElementById("text2").style.display = "block";
}

function esconder(params) {
    document.getElementById("text2").style.display = "none";
}

function agrandar(params) {
    document.getElementById("img").style.width = "100%"
}

function achicar(params) {
    document.getElementById("img").style.width ="20%"
}
function letragrande()
    {
    document.getElementById("caja3").style.fontSize = "200%"
}
function letrachica (){
    document.getElementById("caja3").style.fontSize = "100%"
}